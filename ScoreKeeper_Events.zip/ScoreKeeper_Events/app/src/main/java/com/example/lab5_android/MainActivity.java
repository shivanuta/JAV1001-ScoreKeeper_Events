package com.example.lab5_android;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.button.MaterialButton;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    private Spinner spinner;
    private MaterialButton tAButtonAdd, tAbuttonSub;
    private MaterialButton tBButtonAdd, tBbuttonSub;
    private MaterialButton resetButton, winnerButton;
    private TextView tAScoreTextView, tBScoreTextView;
    private int tAScore = 0, tBScore = 0; // local variables to maintain score state
    private ArrayList<Integer> pointsList = new ArrayList<>();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        spinner = (Spinner) findViewById(R.id.spinner);
        for (int i = 0; i < 6; i++) {
            pointsList.add(i + 1); // add points for spinner
        }
        // define array adapter with scores for spinner
        ArrayAdapter<Integer> spinnerArrayAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, pointsList);
        // set adapter to spinner
        spinner.setAdapter(spinnerArrayAdapter);

        /*
         * Initialise Buttons and assign OnclickListeners for all Buttons
         * Initialise TextViews
         * */
        tAButtonAdd = findViewById(R.id.team_a_add);
        tAButtonAdd.setOnClickListener(this);
        tAbuttonSub = findViewById(R.id.team_a_subtract);
        tAbuttonSub.setOnClickListener(this);
        tBButtonAdd = findViewById(R.id.team_b_add);
        tBButtonAdd.setOnClickListener(this);
        tBbuttonSub = findViewById(R.id.team_b_subtract);
        tBbuttonSub.setOnClickListener(this);
        resetButton = findViewById(R.id.reset_button);
        resetButton.setOnClickListener(this);
        winnerButton = findViewById(R.id.winner_button);
        winnerButton.setOnClickListener(this);
        tAScoreTextView = findViewById(R.id.team_a_score);
        tBScoreTextView = findViewById(R.id.team_b_score);
    }

    private int pointsToUpdate() {
        return (int) spinner.getSelectedItem(); // get the current selected point from spinner
    }

    @Override
    public void onClick(View view) {
        int temp = -1;
        switch (view.getId()) {
            /*
             * Add or Subtract scores from Teams
             * maintain scores to minimum 0
             */
            case R.id.team_a_add:
                tAScore = pointsToUpdate() + tAScore;
                tAScoreTextView.setText(String.valueOf(tAScore));
                break;
            case R.id.team_b_add:
                tBScore = pointsToUpdate() + tBScore;
                tBScoreTextView.setText(String.valueOf(tBScore));
                break;
            case R.id.team_a_subtract:
                temp = tAScore - pointsToUpdate();
                if (temp >= 0) {
                    tAScore = temp;
                } else {
                    tAScore = 0;
                    Toast.makeText(this, "Minimum score is 0.", Toast.LENGTH_SHORT).show();
                }
                tAScoreTextView.setText(String.valueOf(tAScore));
                break;
            case R.id.team_b_subtract:
                temp = tBScore - pointsToUpdate();
                if (temp >= 0) {
                    tBScore = temp;
                } else {
                    tBScore = 0;
                    Toast.makeText(this, "Minimum score is 0.", Toast.LENGTH_SHORT).show();
                }
                tBScoreTextView.setText(String.valueOf(tBScore));
                break;
            case R.id.reset_button:
                // Reset all scores
                tBScore = 0;
                tBScoreTextView.setText(String.valueOf(tBScore));
                tAScore = 0;
                tAScoreTextView.setText(String.valueOf(tAScore));
                break;
            case R.id.winner_button:
                // Check which team won
                // Display results in Alert Dialog
                AlertDialog.Builder builder = new AlertDialog.Builder(this);
                if (tAScore > tBScore) {
                    builder.setMessage("Team A won the Game.\nCongratulations!");
                } else if (tAScore < tBScore) {
                    builder.setMessage("Team B won the Game.\nCongratulations!");
                } else if (tAScore == tBScore) {
                    builder.setMessage("Its a Draw!");
                }

                builder.setCancelable(false);
                builder.setPositiveButton("Continue", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        dialog.cancel();
                    }
                });

                AlertDialog alertDialog = builder.create();
                alertDialog.show();
                break;
        }
    }
}